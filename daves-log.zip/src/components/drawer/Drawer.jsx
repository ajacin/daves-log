import React, { useState } from "react";

// import component 👇
import Drawer from "react-modern-drawer";

//import styles 👇
import "react-modern-drawer/dist/index.css";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faBars } from "@fortawesome/free-solid-svg-icons";
import DrawerItems from "./DrawerItems";

const AppDrawer = () => {
  const [isOpen, setIsOpen] = useState(false);

  const toggleDrawer = () => {
    setIsOpen((prevState) => !prevState);
  };

  return (
    <>
      <button 
        onClick={toggleDrawer} 
        className="fixed top-4 left-4 z-[1001] p-2 bg-purple-600 rounded-md shadow-lg hover:bg-purple-700 transition-colors duration-200 cursor-pointer"
      >
        <FontAwesomeIcon
          color="white"
          icon={faBars}
          size="xl"
        />
      </button>

      <Drawer
        open={isOpen}
        onClose={toggleDrawer}
        direction="left"
        size={280}
        zIndex={1000}
        className="drawer-content"
      >
        <DrawerItems
          setIsDrawerOpen={setIsOpen}
          toggleDrawer={toggleDrawer}
        />
      </Drawer>

      <style jsx global>{`
        .drawer-content {
          background-color: white !important;
          box-shadow: 2px 0 8px rgba(0, 0, 0, 0.15);
        }
        .EZDrawer__overlay {
          z-index: 999 !important;
        }
      `}</style>
    </>
  );
};

export default AppDrawer;
