const jsonData = [
  {
    title: "Airtel Recharge",
    date: "2024-03-16",
  },
  {
    title: "292 Falcon Dr Closing",
    date: "2024-03-28",
  },
];

export default jsonData;
